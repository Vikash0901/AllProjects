let CreateAccount = document.getElementById("CreateAccount");
//let FormData = new FormData(document.getElementById("CreateAccount"))
//var formElements = document.forms['SignUpForm'].elements['text'];

CreateAccount.addEventListener('click', function (e) {
    //e.preventDefault();
    alert("Account created");
    console.log(e);
    //console.log(formElements);
    console.log(CreateAccount.querySelector('input[name="FullName"]'));
});