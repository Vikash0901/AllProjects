let secretNum=Math.trunc(Math.random()*20)+1 ;
let score=20;
let highscore=0;
let message=document.querySelector('.message');
// document.querySelector('.number').textContent=secretNum;
document.querySelector('header button').addEventListener('click', function(){
    score=20;
    secretNum=Math.trunc(Math.random()*20)+1 ;
    message.textContent='Start Guessing... ';
    document.querySelector('.score').textContent=score;
    document.querySelector('.number').textContent='?';
    document.querySelector('.guess').value='';
    document.querySelector('body').style.backgroundColor='#222';
    document.querySelector('.number').style.width='15rem';
    // console.log('clicked');
})

document.querySelector('.check').addEventListener('click', function(){
    const guess=Number(document.querySelector('.guess').value);
    console.log(guess ,typeof guess);

    ///when no input
    if(!guess){
        message.textContent='! No Number';

        /// here wins the game
    }else if(guess===secretNum){
        message.textContent='Correct Number !';
        // score=20;
        document.querySelector('.score').textContent=score;
        document.querySelector('.number').textContent=secretNum;

        document.querySelector('body').style.backgroundColor='#60b347';
        document.querySelector('.number').style.width='30rem';

        if(score > highscore){
            highscore=score;
            document.querySelector('.highscore').textContent=highscore;

        }
    }
    else if(guess !== secretNum){
            if(score >1){
            message.textContent= guess > secretNum ? "Too High...." :"Too Low..";
            score--;
            document.querySelector('.score').textContent=score;
            }
            else{
                message.textContent="You hv lost the game";
                document.querySelector('.score').textContent=0;
            }
    }
    // else if(guess > secretNum){
    //     if(score >1){
    //     document.querySelector('.message').textContent="Too High";
    //     score--;
    //     document.querySelector('.score').textContent=score;
    //     }
    //     else{
    //         document.querySelector('.message').textContent="You hv lost the game";
    //         document.querySelector('.score').textContent=0;
    //     }
    //     ///score is low
    // }else if(guess < secretNum){
    //     if(score > 1){
    //     document.querySelector('.message').textContent="Too Low";
    //     score--;
    //     document.querySelector('.score').textContent=score;
    //     }
    //     else{
    //         document.querySelector('.message').textContent="Lost the game";
    //     }
    // }
})
